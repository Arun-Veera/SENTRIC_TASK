module.exports = {
    accessToken :'SERVERSIDEDEFAULTACCESSTOKEN'
}